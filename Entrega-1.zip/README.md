# Laboratorio 1:

---

> **Universidad:** Universidad Técnica Federico Santa María (UTFSM)  
> **Curso:** Optimizacion (INF292) — 1° Semestre/2026  
> **Grupo:** 9
>
> **Integrantes:**
> * Vicente Rodríguez Rogers    | 21.303.222-4 | 202273503-1 
> * Javier Gana Muñoz           | 21.343.407-1 | 202373540-k 
> * Matias Obando Carrillo      | 21.564.491-k | 202404531-8 
> * Hans Rodriguez Christiansen | 21.911.211-4 | 202404623-3

---

##  Herramientas Utilizadas

* **Manejo de repositorio:** GitHub
* **Editor:** Visual Studio Code (codigo) , Overleaf (latex)
* **Aplicaciones:** MiniZincIDE (gecode 6.3.0)

##  Ambientes de Ejecución

* **Sistemas Operativos:** 
    * Windows 11
    * Ubuntu 22.04.5 LTS 

##  Estructura del repositorio

```bash
├── code/
    ├── Instancias/: Guarda todas las instancias generadas aleatoriamente
    ├── Instanciador.py: Codigo encargado de crear todas las instancias aleatorias
    └── Makefile
├── Docs
    ├── Informe-Grupo-9.pdf: Informe de la entrega 1
    └── Entrega_1__optimizacion: Latex del informe de la entrega 1
└── README.md
```
    
##  Instrucciones de Ejecución
* Creacion de datos (Instancias aleatorias):
    * abri una terminal dentro de la carpeta ***code***
    * Ejecutar el comando ***make*** en la terminal.

##  Consideraciones
- El informe fue Creado en base a latex desde el editor Overleaf que permite trabajar cooperativamente. El
enlace al proyecto se encuentra a continuación: [proyecto](https://www.overleaf.com/9233446427bvdxbxhtkjkt#c4a623)     
- Para los datos factibles se siguio los datos entregados en la tabla para los valores de p, CD y ZD. y para el resto
se tomo datos arbitrarios que mas o menos se ajusten proporcionalmente a los demas datos.
- El proyecto se encuentra en el siguiente repositorio de github: [repositorio](https://github.com/MrDoppelganger/Opti_Grupo_9.git)

##  Supuestos
- Se asume que se mantiene la estructura del repositorio, haciendo énfasis específicamente en la existencia de la carpeta Instancias/ dentro de code/ , ya que el script de python asume que sí existe.
- Para asegurar el correcto funcionamiento del script de python, en la terminal se debe estar en la carpeta code/ antes de ejecutar el comando make.
